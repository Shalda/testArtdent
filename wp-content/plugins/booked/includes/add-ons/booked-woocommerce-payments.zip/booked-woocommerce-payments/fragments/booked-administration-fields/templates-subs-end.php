<?php if ( $look_for_subs==='paid-service' ): ?>
		</ul>
		<button class="cfButton button" data-type="single-paid-service"><i class="booked-icon booked-icon-plus"></i>&nbsp;&nbsp;<?php _e('WooCommerce Product', 'booked-woocommerce-payments'); ?></button>
		<span class="cf-delete"><i class="booked-icon booked-icon-close"></i></span>
	</li>
<?php endif ?>
